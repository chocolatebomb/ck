#include "fitxa.h"
#include <iostream>
using namespace std;

void Fitxa::afegeixMoviment(const Moviment& moviment)
{
	if (m_nMoviments < MAX_MOVIMENTS)
	{
		m_movimentsValids[m_nMoviments++] = moviment;
	}
}

void Fitxa::netejaMoviments()
{
	m_nMoviments = 0;
}

Moviment Fitxa::getMoviment(int index) const
{
	if (index >= 0 && index < m_nMoviments)
		return m_movimentsValids[index];
	else
		return Moviment();
}