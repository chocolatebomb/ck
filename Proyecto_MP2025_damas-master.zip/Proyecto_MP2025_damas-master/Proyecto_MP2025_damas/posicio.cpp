#include "posicio.h"
#include <iostream>
using namespace std;

Posicio::Posicio(const string& posicio)
{
    char lletraColumna = posicio[0];
    char xifraFila = posicio[1];
    m_columna = lletraColumna - 'A';
    m_fila = xifraFila - '1';
}

string Posicio::toString() const
{
    char lletraColumna = 'A' + m_columna;
    char xifraFila = '1' + m_fila;
    string resultat = "";
    resultat += lletraColumna;
    resultat += xifraFila;
    return resultat;
}