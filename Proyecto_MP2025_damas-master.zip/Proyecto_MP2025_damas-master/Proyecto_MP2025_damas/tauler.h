#pragma once
#ifndef TAULER_H
#define TAULER_H

#include <string>
#include "fitxa.h"
#include "posicio.h"

class Tauler
{
public:
    Tauler();
    void inicialitza(const string& nomFitxer);
    void actualitzaMovimentsValids();
    bool mouFitxa(const Posicio& origen, const Posicio& desti);
    void getPosicionsPossibles(const Posicio& origen, int& nPosicions, Posicio posicionsPossibles[]) const;
    string toString() const;

private:
    Fitxa m_tauler[N_FILES][N_COLUMNES];

    bool posicioValida(const Posicio& pos) const;
    void netejaMovimentsValids();
};

#endif
