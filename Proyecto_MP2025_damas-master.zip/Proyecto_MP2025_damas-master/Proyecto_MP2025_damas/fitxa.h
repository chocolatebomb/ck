#pragma once

#ifndef FITXA_H
#define FITXA_H

#include <string>
#include "moviment.h"

const int N_FILES = 8;
const int N_COLUMNES = 8;
const int MAX_MOVIMENTS = 20;

typedef enum
{
	TIPUS_NORMAL,
	TIPUS_DAMA,
	TIPUS_EMPTY
} TipusFitxa;

typedef enum
{
	COLOR_NEGRE,
	COLOR_BLANC,
} ColorFitxa;

class Fitxa
{
public:
	Fitxa() : m_tipus(TIPUS_EMPTY), m_color(COLOR_NEGRE), m_nMoviments(0) {}
	Fitxa(TipusFitxa tipus, ColorFitxa color) : m_tipus(tipus), m_color(color), m_nMoviments(0) {}

	TipusFitxa getTipus() const { return m_tipus; }
	ColorFitxa getColor() const { return m_color; }
	int getNMoments() const { return m_nMoviments; }
	Moviment getMoviment(int index) const;
	void setTipus(TipusFitxa tipus) { m_tipus = tipus; }
	void setColor(ColorFitxa color) { m_color = color; }

	void convertirDama() { m_tipus = TIPUS_DAMA; }
	void afegeixMoviment(const Moviment& moviment);
	void netejaMoviments();
private:
	Moviment m_movimentsValids[MAX_MOVIMENTS];
	int m_nMoviments;
	TipusFitxa m_tipus;
	ColorFitxa m_color;
};

#endif
