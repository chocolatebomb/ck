#include "tauler.h"
#include <fstream>
#include <sstream>
#include <iostream>
using namespace std;

Tauler::Tauler()
{
    for (int i = 0; i < N_FILES; ++i)
    {
        for (int j = 0; j < N_COLUMNES; ++j)
        {
            TipusFitxa tipus = TIPUS_EMPTY;
            ColorFitxa color = COLOR_NEGRE;
            m_tauler[i][j] = Fitxa(tipus, color);
        }
    }
}

void Tauler::inicialitza(const string& nomFitxer)
{
    ifstream fitxer(nomFitxer);
    string posicio;
    for (int i = 0; i < N_FILES && getline(fitxer, posicio); ++i)
    {
        for (int j = 0; j < N_COLUMNES && j < posicio.size(); ++j)
        {
            char c = posicio[j];
            TipusFitxa tipus = TIPUS_NORMAL;
            ColorFitxa color;
            switch (c)
            {
                case 'O':
                {
                    color = COLOR_BLANC;
                } break;
                case 'X':
                {
                    color = COLOR_NEGRE;
                } break;
                case 'D':
                {
                    tipus = TIPUS_DAMA;
                    color = COLOR_BLANC;
                } break;
                case 'R':
                {
                    tipus = TIPUS_DAMA;
                    color = COLOR_NEGRE;
                } break;
                default:
                {
                    tipus = TIPUS_EMPTY;
                    color = COLOR_NEGRE;
                } break;
            }
            m_tauler[i][j] = Fitxa(tipus, color);
        }
    }
}

void Tauler::actualitzaMovimentsValids()
{
    // Aix� hauria de recalcular tots els moviments v�lids per cada fitxa al tauler.
    // Ara mateix nom�s netejem tots els moviments.
    netejaMovimentsValids();

    // Aqu� hauries d'afegir la l�gica que dep�n de les regles del joc per actualitzar els moviments
}

bool Tauler::mouFitxa(const Posicio& origen, const Posicio& desti)
{
    if (!posicioValida(origen) || !posicioValida(desti))
        return false;

    Fitxa& f_origen = m_tauler[origen.getFila()][origen.getColumna()];
    Fitxa& f_desti = m_tauler[desti.getFila()][desti.getColumna()];

    if (f_origen.getTipus() == TIPUS_EMPTY || f_desti.getTipus() != TIPUS_EMPTY)
        return false;

    f_desti = f_origen;
    f_origen = Fitxa(); // Assignem una fitxa buida
    return true;
}

void Tauler::getPosicionsPossibles(const Posicio& origen, int& nPosicions, Posicio posicionsPossibles[]) const
{
    nPosicions = 0;

    if (!posicioValida(origen))
        return;

    const Fitxa& fitxa = m_tauler[origen.getFila()][origen.getColumna()];

    if (fitxa.getTipus() == TIPUS_EMPTY)
        return;

    // Exemple b�sic: intentar moure en diagonal
    int direccions[4][2] = { {1, 1}, {1, -1}, {-1, 1}, {-1, -1} };

    for (int d = 0; d < 4; ++d)
    {
        int novaFila = origen.getFila() + direccions[d][0];
        int novaCol = origen.getColumna() + direccions[d][1];
        if (novaFila >= 0 && novaFila < N_FILES && novaCol >= 0 && novaCol < N_COLUMNES)
        {
            if (m_tauler[novaFila][novaCol].getTipus() == TIPUS_EMPTY)
            {
                posicionsPossibles[nPosicions++] = Posicio(novaFila, novaCol);
            }
        }
    }
}

string Tauler::toString() const
{
    stringstream ss;
    for (int i = 0; i < N_FILES; ++i)
    {
        for (int j = 0; j < N_COLUMNES; ++j)
        {
            const Fitxa& f = m_tauler[i][j];
            if (f.getTipus() == TIPUS_EMPTY)
                ss << '.';
            else if (f.getColor() == COLOR_BLANC)
                ss << (f.getTipus() == TIPUS_DAMA ? 'B' : 'b');
            else
                ss << (f.getTipus() == TIPUS_DAMA ? 'N' : 'n');
        }
        ss << '\n';
    }
    return ss.str();
}

bool Tauler::posicioValida(const Posicio& pos) const
{
    return pos.getFila() >= 0 && pos.getFila() < N_FILES &&
        pos.getColumna() >= 0 && pos.getColumna() < N_COLUMNES;
}

void Tauler::netejaMovimentsValids()
{
    // Aquesta funci� buidaria tots els moviments de totes les fitxes
    // Per implementar completament, caldria que la classe Fitxa permet�s eliminar moviments
}
