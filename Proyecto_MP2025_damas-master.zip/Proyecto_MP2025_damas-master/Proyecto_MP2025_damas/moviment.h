#pragma once
#ifndef MOVIMENT_H
#define MOVIMENT_H

#include "posicio.h"

const int MAX_POSICIONS_MOVIMENT = 12;
const int MAX_FITXES_ELIMINADES = 12;

class Moviment 
{
public:
    Moviment() : m_nPosicions(0), m_nFitxesEliminades(0) {}
    void afegeixPosicio(const Posicio& pos) { m_posicions[m_nPosicions++] = pos; }
    void afegeixFitxaEliminada(const Posicio& pos){ m_fitxesEliminades[m_nFitxesEliminades++] = pos; }
    int getNPosicions() const { return m_nPosicions; }
    int getNFitxesEliminades() const { return m_nFitxesEliminades; }
    Posicio getPosicio(int i) const { return m_posicions[i]; }
    Posicio getFitxaEliminada(int i) const { return m_fitxesEliminades[i]; }
    bool esSalt() const { return m_nFitxesEliminades > 0; }
private:
    Posicio m_posicions[MAX_POSICIONS_MOVIMENT];
    int m_nPosicions;
    Posicio m_fitxesEliminades[MAX_FITXES_ELIMINADES];
    int m_nFitxesEliminades;
};

#endif
